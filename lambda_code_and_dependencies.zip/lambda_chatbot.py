import mysql.connector
import json



def lambda_handler(event, context):
    
    '''
    1. Connect to the database
    2. Identify the intent.
    3. Activate the response generation for the corresponding intent
    4. Send the response to the user

    '''
    # mydb = mysql.connector.connect(
    #     host="immersionlexjuly2020.cqndzdktzpe9.us-east-1.rds.amazonaws.com",
    #     port=3306,
    #     user="admin",
    #     password="Idexcel123")
    
    # mycursor = mydb.cursor()
    # mydb.commit()
    # mycursor.close()
    try:
        # 1. Connect to database
        mydb = mysql.connector.connect(
        host="immersionlexjuly2020.cqndzdktzpe9.us-east-1.rds.amazonaws.com",
        port=3306,
        user="admin",
        password="Idexcel123")
    
        
        if event['currentIntent']['name'] == 'totalcategories':
            sql_stmt = "SELECT count(*) FROM immersionlexjuly2020.inventory;"
            # sql_stmt = "show pocdata1.tables;"
            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult = mycursor.fetchall()
            mydb.commit()
            mycursor.close()
            response_sql = "There are " + str(myresult[0][0]) + " categories in total"
        
        elif event['currentIntent']['name'] == 'totaltobesold':

            sql_stmt = "SELECT sum(remaining) FROM immersionlexjuly2020.inventory;"
            # sql_stmt = "show pocdata1.tables;"
            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult = mycursor.fetchall()
            
            sql_stmt = "SELECT sum(totalno) FROM immersionlexjuly2020.inventory;"
            # sql_stmt = "show pocdata1.tables;"
            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult1 = mycursor.fetchall()
            
            mydb.commit()
            mycursor.close()
            response_sql = "There are " + str(myresult[0][0]) + " number of items yet to be sold out of " +  str(myresult1[0][0]) 
            
        elif event['currentIntent']['name'] == 'gadgetinventoryno':
            number = event['currentIntent']['slotDetails']['number']['originalValue']
            operator = event['currentIntent']['slotDetails']['operator']['originalValue']
            if operator == 'greater':
                sql_stmt = "SELECT gadgets FROM immersionlexjuly2020.inventory where remaining > " + number + ";"
            else:
                sql_stmt = "SELECT gadgets FROM immersionlexjuly2020.inventory where remaining < " + number + ";"
            
            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult = mycursor.fetchall()
            f_list = []
            
            for item in myresult:
	            f_list.append(item[0])
	            
            mydb.commit()
            mycursor.close()
            if f_list!=[]:
                response_sql = str(f_list)
            else:
                response_sql = 'no records found'
           
            
        elif event['currentIntent']['name'] == 'gadgetmonthnumber':
            number = str(event['currentIntent']['slotDetails']['number']['originalValue'])
            month = event['currentIntent']['slotDetails']['month']['originalValue']
            operator = event['currentIntent']['slotDetails']['operator']['originalValue']
            if operator == 'greater':
                sql_stmt = "SELECT gadgets FROM immersionlexjuly2020.inventory where " + month + " > " + number + ";"
            else:
                sql_stmt = "SELECT gadgets FROM immersionlexjuly2020.inventory where " + month + " < " + number + ";"
            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult = mycursor.fetchall()
            f_list = []
            
            for item in myresult:
	            f_list.append(item[0])
	            
            mydb.commit()
            mycursor.close()
            if f_list!=[]:
                response_sql = str(f_list)
            else:
                response_sql = 'no records found'
            
        elif event['currentIntent']['name'] == 'gadgetsold':
            
            month = event['currentIntent']['slotDetails']['month']['originalValue']
            gadget = event['currentIntent']['slotDetails']['gadget']['originalValue']
            
            sql_stmt = "SELECT " + month + " FROM immersionlexjuly2020.inventory where gadgets = " + "'" + gadget + "';"

            mycursor = mydb.cursor()
            mycursor.execute(sql_stmt)
          
            #fetching required data
            myresult = mycursor.fetchall()
            mydb.commit()
            mycursor.close()
            response_sql = str(myresult[0][0]) + " " + gadget+ " " +"units were sold in "+ month
          
    finally:
        mycursor = mydb.cursor()
        mycursor.close()
        response = {"sessionAttributes": {
        "key1": "value1",
        "key2": "value2"}, 
        "dialogAction": {     
          "type": "Close",
          "fulfillmentState": "Fulfilled",
          "message": {       
             "contentType": "PlainText",
             "content": response_sql
            
          },} }
        return response


